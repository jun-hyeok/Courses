#include <stdio.h>
#include <stdlib.h>

int main()
{
    char word[20];
    int vowel_num=0;

    printf("Input the word : ");


    /*

        Fill this code

    */

    printf("%s have %d of vowels",word,vowel_num);
    return 0;
}

