#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1, num2;

    int toEng;

    int arr[10] = {3525234, 64124525, 84363472, 5457574, 53453, 8734724, 934675, 74835, 34580, 12343845};
    double answer = 1;

    char ch;
    FILE *fp;

    printf("1. Input two integer value and print sum of them.\n");


    printf("2. Input one number (1~3) and print it with English.\n");


    printf("3. print product(*) of arr[10]'s odd element.\n");


    printf("4. Read \"47-final-1-text.txt\" and print all\n");




   return 0;
}
